package com.example.apiSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
